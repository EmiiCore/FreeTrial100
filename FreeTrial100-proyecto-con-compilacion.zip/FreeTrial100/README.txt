FreeTrial100 - proyecto Android de demostración

Este proyecto es una aplicación independiente de ejemplo que inicia un periodo
local de 100 días en el primer lanzamiento y muestra los días restantes.

Cómo generar el APK:
1. Instala Android Studio y el Android SDK.
2. Abre la carpeta FreeTrial100 en Android Studio.
3. Espera a que Gradle sincronice el proyecto.
4. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio generará el APK en app/build/outputs/apk/debug/.

Nota:
- Este paquete contiene el código fuente, no un APK compilado.
- El contador es educativo y local: cambiar la fecha del teléfono o borrar
  los datos de la aplicación puede afectar el periodo.
- Para producción, la fecha de expiración debe validarse en un servidor.
- Es una app de demostración independiente y no modifica 9xbuddy.

Compilación automática (sin instalar Android Studio localmente):
1. Sube el contenido de esta carpeta a un repositorio GitHub.
2. Abre la pestaña Actions del repositorio.
3. Ejecuta "Build Android APK" (o haz push a la rama main).
4. Cuando termine, descarga el artefacto "FreeTrial100-debug-apk".
5. Dentro del ZIP del artefacto estará app-debug.apk, instalable como APK de depuración.

La compilación remota requiere una cuenta GitHub y que Actions esté habilitado.
